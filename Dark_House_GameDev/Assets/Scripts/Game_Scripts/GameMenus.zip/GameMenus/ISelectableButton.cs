﻿namespace GameMenus
{
    // public interface ISelectableButton
    // {
    //     void Inject(IMenuTemplate menuTemplate);
    //     void OnLeavingClicking();
    //     void OnClicking();
    // }
}